<?php
while(true) {

if (isset($argv)) {
if (count($argv)==5)  {
$code=$argv[1];
$secret=$argv[2];
$appname=$argv[3];
$server=$argv[4];

$server=str_replace(":","%3A",$server);
$server=str_replace("/","%2F",$server);

//echo "<br>\nserver:".$server;
//echo "<br>\ncode:".$code;
//echo "<br>\nsecret:".$secret;


$ch = curl_init("https://api.steemconnect.com/api/oauth2/token");
curl_setopt($ch,CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POSTFIELDS,"code=".$code."&client_secret=gumby");
$result="";
if (($result=curl_exec($ch)) === false) {}
//echo $result;
echo "<br>\n accesscode:";
$access_code=substr($result,strpos($result,":")+2,strpos($result,".")-16);
echo substr($result,strpos($result,":")+1,strpos($result,".")-16);
$refresh=substr($result,strpos($result,"refresh_token")+16,strpos($result,"expires_in")-15);
echo "<br>\nrefresh:";
echo substr($refresh,0,strpos($refresh,".")+1);
$refresh= substr($refresh,0,strpos($refresh,".")+1);

echo "<br>\nuser:";
//echo substr($result,strpos($result,"username\"")+11,-2);
$user=substr($result,strpos($result,"username\"")+11,-2);
echo $user;
if (ctype_alnum($user)) {
$fk=fopen($user.".rfs",'w');
fwrite($fk,$refresh);
chmod($user.".rfs", 0644);
fclose($fk);

$fk=fopen($user.".acc",'w');
fwrite($fk,$access_code);
chmod($user.".acc", 0644);
fclose($fk);


}

}
else
{
if (!isset($appname)) {$appname="oratione";}
if (!isset($server)) {$server="http://127.0.0.1:8080";$server=str_replace(":","%3A",$server);$server=str_replace("/","%2F",$server);}
//echo strlen($appname."\n");
//echo strlen($server."\n");
echo "<br>\n\nenter php startengine.php [code] [secret]<br>\n<a href=\"https://beta.steemconnect.com/login-request/";
echo $appname."?response_type=code&redirect_uri=".$server;
echo "%2Fphp%2frefresh.php&scope=vote,comment,offline&scope=posting\">click here to get code</a>";}
}else 
{
$appname="oratione";
$server="http://127.0.0.1:8080";
$server=str_replace(":","%3A",$server);
$server=str_replace("/","%2F",$server);
echo "<br>server:".$server;


echo "<br>\n\nplease load this offline from the commandline and enter<br>\php startengine.php start [botnumber] [user] [code]<br>\n<a href=\"https://beta.steemconnect.com/login-request/";
echo $appname."?response_type=code&redirect_uri=".$server;
echo "%2Fphp%2Findex.php&scope=vote,comment,offline&scope=posting\">click here to get code</a>";}

sleep(3*24*60*60);
}//end while
?>